/**Task 1 By Ksenia Vyazalova**/

#include <iostream>
using namespace std;

// Define a Location class for storing latitude and longitude coordinates
class Location {
    private:
        int degrees;  // Degrees of latitude or longitude
        float minutes;  // Minutes of latitude or longitude
        char direction;  // Direction letter (N, S, E, or W)
    public:
        // Member function to get the position from the user
        void get_pos() {
            cout << "Input degrees between 0 and 180: ";
            cin >> degrees;
            cout << "Input minutes between 0 and 60: ";
            cin >> minutes;
            cout << "Input direction (E/W/N/S) : ";
            cin >> direction;
        }

        // Member function to display the position in the required format
        void display() {
            cout << degrees << '\xF8' << minutes << "'" << direction << " ";
        }
};

// Define a Yacht class for storing the yacht number and its location
class Yacht {
    private:
        static int serial_number;  // Static member variable for the serial number
        int yacht_number;  // Member variable for the yacht number
        Location location;  // Member variable for the yacht location
    public:
        // Constructor for assigning a unique serial number and yacht number
        Yacht() {
            yacht_number = ++serial_number;
        }

        // Member function to get the yacht's location from the user
        void get_pos() {
            location.get_pos();
        }

        // Member function to display the yacht's number and location
        void display() {
            cout << "\nThe ship serial number is :" << yacht_number << endl;
            cout << "and it's position is: ";
            location.display();
            cout << "Latitute ";
            location.get_pos();
            cout << "Longtitute\n";
        }
};

// Initialize the static member variable for the serial number
int Yacht::serial_number = 0;

// Main function to create three yachts, get their positions, and display their information
int main() {
    cout << "Enter the Location of the first ship:\n";
    Yacht yacht1;
    yacht1.get_pos();

    cout << "\nEnter the Location of the second ship:\n";
    Yacht yacht2;
    yacht2.get_pos();

    cout << "\nEnter the Location of the third ship:\n";
    Yacht yacht3;
    yacht3.get_pos();

    cout << "\nWelcome to Ocean Race 2021-22*\n";
    yacht1.display();
    yacht2.display();
    yacht3.display();

    return 0;
}
